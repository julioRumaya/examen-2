<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <link rel="stylesheet" href="css/style.css">
 <title>EJERCICIO 2</title>
</head>
<body>
 <div id="encabezado">
 <div id="menu">
 <ul>
 <li><a href="index.html" >INICIO</a></li>
 <li><a href="ejercicio1.php">EJERCICIO 1</a></li>
 <li><a href="ejercicio2.php" >EJERCICIO 2</a></li>
 <li><a href="ejercicio3.php" >EJERCICIO 3</a></li>
 <li><a href="ejercicio4.php" >EJERCIO 4</a></li>
 </ul>
 </div>
 </div>

 <div class="areaPrincipal">
 <div id="datos">
 <H1>EJERCICIO 2</H1>



<html>
<head>
<H1>SUMA DE DOS NUMEROS</H1> 
</head>
<body>
<form action="" method="POST">
dato1: <input type="text" name="a" value="" /></br>
dato2: <input type="text" name="b" value="" /></br>
<input type="Submit" name="sumar" value="SUMA" /></br>
<?php

$a = intval($_POST['a']);
$b = intval($_POST['b']);

?>
<?php
$suma = $a + $b;
echo $suma; 
?>




















 </div>
 </div>
 <div class="piePagina"></div>
</body>
</html>
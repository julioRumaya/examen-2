<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <link rel="stylesheet" href="css/style.css">
 <title>EJERCICO 1</title>
</head>
<body>
 <div id="encabezado">
 <div id="menu">
 <ul>
 <li><a href="index.html" >INICIO</a></li>
 <li><a href="ejercicio1.php">EJERCICIO 1</a></li>
 <li><a href="ejercicio2.php" >EJERCICIO 2</a></li>
 <li><a href="ejercicio3.php" >EJERCICIO 3</a></li>
 <li><a href="ejercicio4.php" >EJERCIO 4</a></li>
 </ul>
 </div>
 </div>

 <div class="areaPrincipal">
 <div id="datos">
 <H1>EJERCICIO 1</H1>
 <html> 
<head> 
   <title>Comparando Números</title> 
</head> 
<body> 
<H1>COMPARACION DE DOS NUMEROS</H1> 
<FORM ACTION="EJERCICIO1.php" METHOD="GET"> 
   <H1> Introduzca el primer número:</H1> 
    <INPUT TYPE="text" NAME="numero1" maxlength="6" size="6"><BR> 
  <H1> Introduzca el segundo número:</H1> 
   <INPUT TYPE="text" NAME="numero2" maxlength="6" size="6"><BR> 
   <H1>  <INPUT TYPE="submit" VALUE="Comparar"> </H1>
  <H1> <INPUT TYPE="reset" VALUE="Limpiar"></H1>
</FORM> 
</body> 
</html>


<html> 
<body> 
<H1> 
<?php 
$n1=intval($_GET['numero1']);
$n2=intval($_GET['numero2']);

if ($n1>$n2)
{
    echo "El numero mayor es (" . $n1 . ")";
}
elseif ($n1==$n2){
    echo "los dos numeros son iguales (" .$n2. ")";
}
else{
    echo "El numero mayor es(" .$n2. ")";
}
 ?>
</H1>
</body> 
</html>
 </div>
 </div>
 <div class="piePagina"></div>
</body>
</html>
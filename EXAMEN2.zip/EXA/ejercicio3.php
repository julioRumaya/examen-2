<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <link rel="stylesheet" href="css/style.css">
 <title>ejercicio 3</title>
</head>
<body>
 <div id="encabezado">
 <div id="menu">
 <ul>
 <li><a href="index.html" >INICIO</a></li>
 <li><a href="ejercicio1.php">EJERCICIO 1</a></li>
 <li><a href="ejercicio2.php" >EJERCICIO 2</a></li>
 <li><a href="ejercicio3.php" >EJERCICIO 3</a></li>
 <li><a href="ejercicio4.php" >EJERCIO 4</a></li>
 </ul>
 </div>
 </div>

 <div class="areaPrincipal">
 <div id="datos">
</head>
<body>
<H1>EJERCICIO 3</H1>
    <H1>TABLAS DE MULTIPLICAR</H1>
    <H1>Escribe un número del 1 al 10 y yo te diré la tabla de multiplicar.</H1>
    <form action="#" method="post">
       <H1>Escribe aquí el número: <input type="text" name="num" maxlength="2" size="2" /></H1>
       <H1><input type="submit" value="Ver tabla de multiplicar." /></H1>
    </form>
    <?php  
    $n=$_POST['num'];
    if ($n<1 or $n>10) 
        {
        echo "no has escrito un nůmero entre el 1 y el 10.";
        }
    else {
         echo "<h4>Tabla del $n:</h4>";
         $i=1;
         while ($i<=10) {
               echo "$n x $i = ".$n*$i."<br/>";
               $i++;
               } 
         }
    ?>   
</body>
</html>


 </div>
 </div>
 <div class="piePagina"></div>
</body>
</html>
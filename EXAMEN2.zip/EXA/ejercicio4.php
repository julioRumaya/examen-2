<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <link rel="stylesheet" href="css/style.css">
 <title>ejercicio 4</title>
</head>
<body>
 <div id="encabezado">
 <div id="menu">
 <ul>
 <li><a href="index.html" >INICIO</a></li>
 <li><a href="ejercicio1.php">EJERCICIO 1</a></li>
 <li><a href="ejercicio2.php" >EJERCICIO 2</a></li>
 <li><a href="ejercicio3.php" >EJERCICIO 3</a></li>
 <li><a href="ejercicio4.php" >EJERCIO 4</a></li>
 </ul>
 </div>
 </div>

 <div class="areaPrincipal">
 <div id="datos">
</head>
<body>
<H1>EJERCICIO 4</H1>
    <H1>LONGITUD DE TEXTO</H1>
    <H1>ESCRIBE UN COMENTARIO </H1>

    <?php 
    if (isset($_POST['cadena'])) echo strlen($_POST['cadena']).' caracteres'; else echo '0 caracteres';
    ?>
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
      <H1>  <input type="text" name="cadena"  maxlength="150" size="100"  autofocus>
        <input type="submit" value="publicar"></H1>
        
    </form>
      
</body>
</html>


 </div>
 </div>
 <div class="piePagina"></div>
</body>
</html>